/****************************************************************************************
 *   FileName    : DBusMsgDef.h
 *   Description : DBus message define Header File
 ****************************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved 
 
This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited 
to re-distribution in source or binary form is strictly prohibited.
This source code is provided ��AS IS�� and nothing contained in this source code 
shall constitute any express or implied warranty of any kind, including without limitation, 
any warranty of merchantability, fitness for a particular purpose or non-infringement of any patent, 
copyright or other third party intellectual property right. 
No warranty is made, express or implied, regarding the information��s accuracy, 
completeness, or performance. 
In no event shall Telechips be liable for any claim, damages or other liability arising from, 
out of or in connection with this source code or the use in the source code. 
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement 
between Telechips and Company.
*
****************************************************************************************/
#ifndef DBUS_MSG_DEF_H
#define DBUS_MSG_DEF_H

#define MICOMMANAGER_PROCESS_DBUS_NAME							"telechips.micom_manager.process"
#define MICOMMANAGER_PROCESS_OBJECT_PATH						"/telechips/micom_manager/process"
#define MICOMMANAGER_EVENT_INTERFACE							"micom_manager.event"

// MICOM_MANAGER SIGNAL EVENT DEFINES
#define SIGNAL_MICOM_MANAGER_POWER								"signal_micom_manager_power"
#define SIGNAL_MICOM_MANAGER_SPEED_CHANGED						"signal_micom_manager_speed_changed"
#define SIGNAL_MICOM_MANAGER_ILLUMINATION_CHANGED				"signal_micom_manager_illumination_changed"
#define SIGNAL_MICOM_MANAGER_GEAR_CHANGED						"signal_micom_manager_gear_changed"
#define SIGNAL_MICOM_MANAGER_CLIMATE_AUTO						"signal_micom_manager_climate_auto"
#define SIGNAL_MICOM_MANAGER_CLIMATE_TEMPERATURE_CHANGED	"signal_micom_manager_climate_temperature_changed"
#define SIGNAL_MICOM_MANAGER_CLIMATE_POWER						"signal_micom_manager_climate_power"
#define SIGNAL_MICOM_MANAGER_CLIMATE_AIR_CONDITIONING			"signal_micom_manager_climate_air_conditioning"
#define SIGNAL_MICOM_MANAGER_CLIMATE_AIR_DIRECTOR_CHANGED	"signal_micom_manager_climate_air_director_changed"
#define SIGNAL_MICOM_MANAGER_CLIMATE_AIR_STREAM_CHANGED		"signal_micom_manager_climate_air_stream_changed"
#define SIGNAL_MICOM_MANAGER_CLIMATE_FRONT_DEFROSTER			"signal_micom_manager_climate_front_defroster"
#define SIGNAL_MICOM_MANAGER_CLIMATE_REAR_DEFROSTER			"signal_micom_manager_climate_rear_defroster"
#define SIGNAL_MICOM_MANAGER_MICOM_TIME_STAMP					"signal_micom_manager_micom_time_stamp"
#define SIGNAL_MICOM_MANAGER_TSOUND_TIME_STAMP				"signal_micom_manager_tsound_time_stamp"
#define SIGNAL_MICOM_MANAGER_EARLYCAM_TIME_STAMP				"signal_micom_manager_earlycam_time_stamp"
#define SIGNAL_MICOM_MANAGER_RECEIVER_TIME_STAMP				"signal_micom_manager_receiver_time_stamp"
#define SIGNAL_MICOM_MANAGER_APP_LAUNCHED						"signal_micom_manager_app_launched"
#define SIGNAL_MICOM_MANAGER_LAST_MODE							"signal_micom_manager_last_mode"
#define SIGNAL_MICOM_MANAGER_TRVC_ON							"signal_micom_manager_trvc_on"

typedef enum {
	SignalMicomManagerPower,
	SignalMicomManagerSpeedChanged,
	SignalMicomManagerIlluminationChanged,
	SignalMicomManagerGearChanged,
	SignalMicomManagerClimateAuto,
	SignalMicomManagerClimateTemperatureChanged,
	SignalMicomManagerClimatePower,
	SignalMicomManagerClimateAirConditioning,
	SignalMicomManagerClimateAirDirectorChanged,
	SignalMicomManagerClimateAirStreamChanged,
	SignalMicomManagerClimateFrontDefroster,
	SignalMicomManagerClimateRearDefroster,
	SignalMicomManagerMicomTimeStamp,
	SignalMicomManagerTSoundTimeStamp,
	SignalMicomManagerEarlyCamTimeStamp,
	SignalMicomManagerReceiverTimeStamp,
	SignalMicomManagerAppLaunched,
	SignalMicomManagerLastMode,
	SignalMicomManagerTrvcOn,
	TotalSignalMicomManagerEvents
} SignalMicomManagerEvent;

extern const char *g_signalMicomManagerEventNames[TotalSignalMicomManagerEvents];


// MICOM_MANAGER METHOD EVENT DEFINES
#define METHOD_MICOM_MANAGER_POWER								"method_micom_manager_power"
#define METHOD_MICOM_MANAGER_CHANGE_SPEED						"method_micom_manager_change_speed"
#define METHOD_MICOM_MANAGER_CHANGE_ILLUMINATION				"method_micom_manager_change_illumination"
#define METHOD_MICOM_MANAGER_CHANGE_GEAR						"method_micom_manager_change_gear"
#define METHOD_MICOM_MANAGER_SET_CLIMATE_AUTO					"method_micom_manager_set_climate_auto"
#define METHOD_MICOM_MANAGER_CHANGE_CLIMATE_TEMPERATURE		"method_micom_manager_change_climate_temperature"
#define METHOD_MICOM_MANAGER_SET_CLIMATE_POWER				"method_micom_manager_set_climate_power"
#define METHOD_MICOM_MANAGER_SET_CLIMATE_AIR_CONDITIONING	"method_micom_manager_set_climate_air_conditioning"
#define METHOD_MICOM_MANAGER_CHANGE_CLIMATE_AIR_DIRECTOR	"method_micom_manager_change_climate_air_director"
#define METHOD_MICOM_MANAGER_CHANGE_CLIMATE_AIR_STREAM		"method_micom_manager_change_climate_air_stream"
#define METHOD_MICOM_MANAGER_SET_CLIMATE_FRONT_DEFROSTER	"method_micom_manager_set_climate_front_defroster"
#define METHOD_MICOM_MANAGER_SET_CLIMATE_REAR_DEFROSTER		"method_micom_manager_set_climate_rear_defroster"
#define METHOD_MICOM_MANAGER_MICOM_TIME_STAMP				"method_micom_manager_mciom_time_stamp"
#define METHOD_MICOM_MANAGER_TSOUND_TIME_STAMP				"method_micom_manager_tsound_time_stamp"
#define METHOD_MICOM_MANAGER_EARLYCAM_TIME_STAMP				"method_micom_manager_earlycam_time_stamp"
#define METHOD_MICOM_MANAGER_RECEIVER_TIME_STAMP				"method_micom_manager_receiver_time_stamp"
#define METHOD_MICOM_MANAGER_LAUNCH_APP						"method_micom_manager_launch_app"
#define METHOD_MICOM_MANAGER_GET_LAST_MODE					"method_micom_manager_get_last_mode"
#define METHOD_MICOM_MANAGER_SET_LAST_MODE					"method_micom_manager_set_last_mode"
#define METHOD_MICOM_MANAGER_SVM_ON							"method_micom_manager_svm_on"
#define METHOD_MICOM_MANAGER_SVM_OFF						"method_micom_manager_svm_off"
#define METHOD_MICOM_MANAGER_FVC_ON							"method_micom_manager_fvc_on"
#define METHOD_MICOM_MANAGER_FVC_OFF						"method_micom_manager_fvc_off"
#define METHOD_MICOM_MANAGER_RVC_ON							"method_micom_manager_rvc_on"
#define METHOD_MICOM_MANAGER_RVC_OFF						"method_micom_manager_rvc_off"
#define METHOD_MICOM_MANAGER_RESET							"method_micom_manager_reset"
#define METHOD_MICOM_MANAGER_ROBUST							"method_micom_manager_robust"


typedef enum {
	MethodMicomManagerPower,
	MethodMicomManagerChangeSpeed,
	MethodMicomManagerChangeIllumination,
	MethodMicomManagerChangeGear,
	MethodMicomManagerSetClimateAuto,
	MethodMicomManagerChangeClimateTemperature,
	MethodMicomManagerSetClimatePower,
	MethodMicomManagerSetClimateAirConditioning,
	MethodMicomManagerChangeClimateAirDirector,
	MethodMicomManagerChangeClimateAirStream,
	MethodMicomManagerSetClimateFrontDefroster,
	MethodMicomManagerSetClimateRearDefroster,
	MethodMicomManagerMicomTimeStamp,
	MethodMicomManagerTSoundTimeStamp,
	MethodMicomManagerEarlyCamTimeStamp,
	MethodMicomManagerReceiverTimeStamp,
	MethodMicomManagerLaunchApp,				/* Micom vehicle Demo */
	MethodMicomManagerGetLastMode,
	MethodMicomManagerSetLastMode,
	MethodMicomManagerSvmOn,
	MethodMicomManagerSvmOff,
	MethodMicomManagerFvcOn,
	MethodMicomManagerFvcOff,
	MethodMicomManagerRvcOn,
	MethodMicomManagerRvcOff,
	MethodMicomManagerReset,
	MethodMicomManagerRobust,
	TotalMethodMicomManagerEvents
} MethodMicomManagerEvent;
extern const char *g_methodMicomManagerEventNames[TotalMethodMicomManagerEvents];


#endif
