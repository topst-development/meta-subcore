#ifndef TRVC_PROCESS_H
#define TRVC_PROCESS_H

#include <QWidget>
#include <QTimer>
#include "TCImageButton.h"

class Trvc : public QWidget
{
    Q_OBJECT
	public:
		Trvc(QWidget *parent = 0);
		~Trvc();
		void Initialize(int screenWidth, int screenHeight);

	private:
		void InitializeSignalSlots(void);
		void RestoreBackground(void);

	private slots:
		void OnRGearTimer();
		void OnClickedRobust();
		void OnClickedDark();
		void OnClickedBright();
		void OnClickedColor();
		void OnClickedCrash();
		void OnClickedExit();

	signals:
		void TrvcChanged(bool status);
		void TrvcRobust();

	private:
		QTimer _timer;
		TCImageButton *_btnRobust;
		TCImageButton *_btnDark;
		TCImageButton *_btnBright;
		TCImageButton *_btnColor;
		TCImageButton *_btnCrash;
		TCImageButton *_btnExit;
		int button;
};

#endif // TRVC_PROCESS_H
