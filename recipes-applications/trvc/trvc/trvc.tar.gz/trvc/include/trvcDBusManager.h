#ifndef TRVC_DBUS_MANAGER_H
#define TRVC_DBUS_MANAGER_H

void InitilaizeTrvcDBusManager(void);
void ReleaseTrvcDBusManager(void);
void SendDBusTrvcOn();
void SendDBusTrvcOff();
void SendDBusTrvcRobust();
void SendDBusTrvcReset();

#endif // TRVC_DBUS_MANAGER_H
