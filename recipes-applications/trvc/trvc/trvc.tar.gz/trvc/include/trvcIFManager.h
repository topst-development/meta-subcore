#ifndef TRVC_IF_MANAGER_H
#define TRVC_IF_MANAGER_H

#include <QObject>

class TrvcIFManager : public QObject
{
	Q_OBJECT

	public:
	    TrvcIFManager(QObject *parent = 0);
		void Initilaize(void);
		void Release(void);

	private slots:
		void SendTrvcStatus(bool status);
		void SendTrvcRobust();
		void SendTrvcReset();

	signals:

	private:
		bool _rGear;
};

TrvcIFManager *GetTrvcIFManager();
#define TRVC_IF_MANAGER	(GetTrvcIFManager())

#endif // TRVC_IF_MANAGER_H
