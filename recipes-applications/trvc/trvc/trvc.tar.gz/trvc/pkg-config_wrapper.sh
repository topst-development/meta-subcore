#!/bin/sh
PKG_CONFIG_SYSROOT_DIR=/home/B110141/works/Yocto/tcc805x_linux_ivi/build/tcc8050-sub/tmp/work/aarch64-telechips-linux/trvc/1.0.0-r0/recipe-sysroot
export PKG_CONFIG_SYSROOT_DIR
PKG_CONFIG_LIBDIR=/home/B110141/works/Yocto/tcc805x_linux_ivi/build/tcc8050-sub/tmp/work/aarch64-telechips-linux/trvc/1.0.0-r0/recipe-sysroot/usr/lib/pkgconfig
export PKG_CONFIG_LIBDIR
exec pkg-config "$@"
