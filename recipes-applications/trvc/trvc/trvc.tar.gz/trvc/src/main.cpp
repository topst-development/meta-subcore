#include <cstdio>
#include <sys/signal.h>
#include <unistd.h>
#ifdef USE_QT5
#include <QApplication>
#else
#include <QtGui/QApplication>
#endif
#include <QDesktopWidget>
#include "TCLog.h"
#include "trvcDBusManager.h"
#include "trvcIFManager.h"
#include "trvc.h"

static void NewExceptionHandler();
static void SignalHandler(int sig);
#ifdef USE_QT5
static void PrintQtMessage(QtMsgType type, const QMessageLogContext &context, const QString &msg);
#else
static void PrintQtMessage(QtMsgType type, const char *msg);
#endif

int main(int argc, char *argv[])
{
#ifdef USE_QT5
	qInstallMessageHandler(PrintQtMessage);
#else
	qInstallMsgHandler(PrintQtMessage);
#endif
	QApplication app(argc, argv);

	signal(SIGTERM, SignalHandler);

	QString argument;
	TCLogInitialize("TRVC", NULL, 0);

	for (int i = 1; i < argc; i++)
	{
		argument = argv[i];
		argument = argument.toUpper();
		if (argument == "--DEBUG")
		{
			TCLogSetLevel(TCLogLevelDebug);
		}
	}

	std::set_new_handler(NewExceptionHandler);

	QDesktopWidget *desktop = QApplication::desktop();
	int ret = 0;
	if (desktop != NULL)
	{
		Trvc *trvc = new Trvc;

		if (trvc != NULL)
		{
			int width, height;

			width = desktop->width();
			height = desktop->height();

			TRVC_IF_MANAGER->Initilaize();
			trvc->Initialize(width, height);
			trvc->hide();

			ret = app.exec();

			if (trvc != NULL)
			{
				delete trvc;
				trvc = NULL;
			}
			TRVC_IF_MANAGER->Release();
		}
		else
		{
			fprintf(stderr, "%s: create trvc process failed\n", __FUNCTION__);
		}
	}
	else
	{
		fprintf(stderr, "Can not get desktop\n");
		ret = -1;
	}
	return ret;
}

static void NewExceptionHandler()
{
	TCLog(TCLogLevelError, "MEMORY ALLOCATION FAILED\n");
	throw std::bad_alloc();
}

static void SignalHandler(int sig)
{
	TCLog(TCLogLevelError, "received signal(%d)\n", __FUNCTION__, sig);
	QApplication::exit(sig);
}

#ifdef USE_QT5
static void PrintQtMessage(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
	QByteArray localMsg = msg.toLocal8Bit();
	switch (type)
	{
		case QtDebugMsg:
			fprintf(stderr, "QtDebug: %s (%s:%u, %s)\n", localMsg.constData(), context.file, context.line, context.function);
			break;
		case QtWarningMsg:
			fprintf(stderr, "QtWarning: %s (%s:%u, %s)\n", localMsg.constData(), context.file, context.line, context.function);
			break;
		case QtCriticalMsg:
			fprintf(stderr, "QtCritical: %s (%s:%u, %s)\n", localMsg.constData(), context.file, context.line, context.function);
			break;
		case QtFatalMsg:
			fprintf(stderr, "QtFatal: %s (%s:%u, %s)\n", localMsg.constData(), context.file, context.line, context.function);
			abort();
	}
}
#else
static void PrintQtMessage(QtMsgType type, const char *msg)
{
	switch (type)
	{
		case QtDebugMsg:
			fprintf(stderr, "QtDebug: %s\n", msg);
			break;
		case QtWarningMsg:
			fprintf(stderr, "QtWarning: %s\n", msg);
			break;
		case QtCriticalMsg:
			fprintf(stderr, "QtCritical: %s\n", msg);
			break;
		case QtFatalMsg:
			fprintf(stderr, "QtFatal: %s\n", msg);
			abort();
			break;
	}
}
#endif

