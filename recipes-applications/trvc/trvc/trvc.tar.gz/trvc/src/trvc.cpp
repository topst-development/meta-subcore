#include <cstdio>
#include <stdint.h>
#include "TCLog.h"
#include "TCInput.h"
#include "trvcIFManager.h"
#include "trvc.h"

#define RVC_CAMERA_SWITCH_NUMBER0_PATH 	"/sys/devices/platform/switch0/switch_status"
#define RVC_CAMERA_SWITCH_NUMBER1_PATH 	"/sys/devices/platform/switch1/switch_status"
#define SWITCHON (49)
#define VIRT_TOUCH_FILE ("/sys/devices/platform/touch_share/touch_state")
#define VIRT_TOUCH_ENABLE ("1")
#define VIRT_TOUCH_DISABLE ("0")
#define INVALID_STATUS (-1)

enum {
	TRVCDark,
	TRVCBright,
	TRVCColor,
	TRVCCrash,
	TRVCStatusMax
};

Trvc::Trvc(QWidget *parent) :
	QWidget(parent),
	button(INVALID_STATUS)
{
	_btnRobust = new TCImageButton(this);
	_btnDark = new TCImageButton(this);
	_btnBright = new TCImageButton(this);
	_btnColor = new TCImageButton(this);
	_btnCrash = new TCImageButton(this);
	_btnExit = new TCImageButton(this);
}

Trvc::~Trvc()
{
}

void Trvc::Initialize(int screenWidth, int screenHeight)
{
	int x = 0;
	int y = 0;
	int t_Width = screenWidth / 3;
	int h_Height = screenHeight / 2;

    fprintf(stderr, "%s: set modal attribute\n", __func__);
    this->setWindowFlags(Qt::FramelessWindowHint | Qt::Popup | Qt::Dialog | Qt::SplashScreen);
    this->setWindowModality(Qt::ApplicationModal);
	this->setGeometry(x, y, 1920, screenHeight);

	_btnRobust->setGeometry(0, 0, t_Width, h_Height);
	_btnDark->setGeometry(t_Width, 0, t_Width, h_Height);
	_btnBright->setGeometry(t_Width * 2, 0, t_Width, h_Height);
	_btnColor->setGeometry(0, h_Height, t_Width, h_Height);
	_btnCrash->setGeometry(t_Width, h_Height, t_Width, h_Height);
	_btnExit->setGeometry(t_Width * 2, h_Height, t_Width, h_Height);

	_timer.start(100); // start timer mili-seconds
	InitializeSignalSlots();

	this->setStyleSheet("background:transparent;");
}

void Trvc::InitializeSignalSlots(void)
{
	Qt::ConnectionType dbusConnectionType = Qt::QueuedConnection;

	// Controls SIGNAL/SLOT
	connect(_btnRobust, SIGNAL(mouseClicked()), this, SLOT(OnClickedRobust()));
	connect(_btnDark, SIGNAL(mouseClicked()), this, SLOT(OnClickedDark()));
	connect(_btnBright, SIGNAL(mouseClicked()), this, SLOT(OnClickedBright()));
	connect(_btnColor, SIGNAL(mouseClicked()), this, SLOT(OnClickedColor()));
	connect(_btnCrash, SIGNAL(mouseClicked()), this, SLOT(OnClickedCrash()));
	connect(_btnExit, SIGNAL(mouseClicked()), this, SLOT(OnClickedExit()));

	connect(this, SIGNAL(TrvcChanged(bool)),
			TRVC_IF_MANAGER, SLOT(SendTrvcStatus(bool)), dbusConnectionType);
	connect(this, SIGNAL(TrvcRobust()),
			TRVC_IF_MANAGER, SLOT(SendTrvcRobust()), dbusConnectionType);

	connect(&_timer, SIGNAL(timeout()), this, SLOT(OnRGearTimer())); // connect Qt Signal/Slot

}

void Trvc::RestoreBackground(void)
{
	this->setStyleSheet("background:transparent;");
}

void Trvc::OnRGearTimer()
{
	FILE *gear, *fp;
	char status;
	gear = fopen(RVC_CAMERA_SWITCH_NUMBER0_PATH, "rb");
	if (gear != NULL)
	{
		(void)fread(&status, sizeof(char), 1, gear);
		(void)fclose(gear);
	}
	if(status == SWITCHON)
	{
		emit TrvcChanged(true);
		fp = fopen(VIRT_TOUCH_FILE, "w+");
		if (fp != NULL)
		{
			(void)fwrite(VIRT_TOUCH_ENABLE, sizeof(char), 1, fp);
			(void)fclose(fp);
		}
		this->show();
	}
	else
	{
		emit TrvcChanged(false);
		fp = fopen(VIRT_TOUCH_FILE, "w+");
		if (fp != NULL)
		{
			(void)fwrite(VIRT_TOUCH_DISABLE, sizeof(char), 1, fp);
			(void)fclose(fp);
		}
		if (this->isVisible())
		{
			this->hide();
		}
	}
}

void Trvc::OnClickedRobust()
{
    emit TrvcRobust();
}

void Trvc::OnClickedDark()
{
	TCLog(TCLogLevelDebug, "%s\n", __FUNCTION__);
	if(button != TRVCDark)
	{
		button = TRVCDark;
		this->setStyleSheet("background-color: rgba(0, 0, 0, 60%)");
	}
	else
	{
		button = INVALID_STATUS;
		RestoreBackground();
	}
}

void Trvc::OnClickedBright()
{
	TCLog(TCLogLevelDebug, "%s\n", __FUNCTION__);
	if(button != TRVCBright)
	{
		button = TRVCBright;
		this->setStyleSheet("background-color: rgba(246, 246, 246, 70%)");
	}
	else
	{
		button = INVALID_STATUS;
		RestoreBackground();
	}
}

void Trvc::OnClickedColor()
{
	TCLog(TCLogLevelDebug, "%s\n", __FUNCTION__);
	if(button != TRVCColor)
	{
		button = TRVCColor;
		this->setStyleSheet("background-color: red");
	}
	else
	{
		button = INVALID_STATUS;
		RestoreBackground();
	}
}

void Trvc::OnClickedCrash()
{
	TCLog(TCLogLevelDebug, "%s\n", __FUNCTION__);
	system("/usr/sbin/syncerror.sh");
}

void Trvc::OnClickedExit()
{
	TCLog(TCLogLevelDebug, "%s\n", __FUNCTION__);
}
