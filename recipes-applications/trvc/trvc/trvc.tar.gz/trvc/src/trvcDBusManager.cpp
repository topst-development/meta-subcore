#include <stdlib.h>
#include <stdio.h>
#include <dbus/dbus.h>
#include <stdint.h>
#include "TCLog.h"
#include "DBusMsgDef.h"
#include "TCDBusRawAPI.h"
#include "trvcIFManager.h"
#include "trvcDBusManager.h"

extern int g_debug;

static DBusMsgErrorCode OnReceivedDBusSignal(DBusMessage *message, const char *interface);
static void MicomManagerSignalDBusProcess(unsigned int id, DBusMessage *message);

void InitilaizeTrvcDBusManager(void)
{
	SetCallBackFunctions(OnReceivedDBusSignal, NULL);
	AddSignalInterface(MICOMMANAGER_EVENT_INTERFACE);
	InitializeRawDBusConnection("T-RVC DBUS");
}

void ReleaseTrvcDBusManager(void)
{
	ReleaseRawDBusConnection();
}
void SendDBusTrvcOn()
{
	DBusMessage *message;

	message = CreateDBusMsgMethodCall(MICOMMANAGER_PROCESS_DBUS_NAME, MICOMMANAGER_PROCESS_OBJECT_PATH,
									  MICOMMANAGER_EVENT_INTERFACE,
									  METHOD_MICOM_MANAGER_RVC_ON,
									  DBUS_TYPE_INVALID);
	if (message != NULL)
	{
		if (!SendDBusMessage(message, NULL))
		{
			fprintf(stderr, "%s: SendDBusMessage failed\n", __FUNCTION__);
		}

		dbus_message_unref(message);
	}
	else
	{
		fprintf(stderr, "%s: CreateDBusMsgMethodCall failed\n", __FUNCTION__);
	}
}

void SendDBusTrvcOff()
{
	DBusMessage *message;

	message = CreateDBusMsgMethodCall(MICOMMANAGER_PROCESS_DBUS_NAME, MICOMMANAGER_PROCESS_OBJECT_PATH,
									  MICOMMANAGER_EVENT_INTERFACE,
									  METHOD_MICOM_MANAGER_RVC_OFF,
									  DBUS_TYPE_INVALID);
	if (message != NULL)
	{
		if (!SendDBusMessage(message, NULL))
		{
			fprintf(stderr, "%s: SendDBusMessage failed\n", __FUNCTION__);
		}

		dbus_message_unref(message);
	}
	else
	{
		fprintf(stderr, "%s: CreateDBusMsgMethodCall failed\n", __FUNCTION__);
	}
}

void SendDBusTrvcRobust()
{
	DBusMessage *message;

	TCLog(TCLogLevelInfo, "%s\n", __FUNCTION__);
	message = CreateDBusMsgMethodCall(MICOMMANAGER_PROCESS_DBUS_NAME, MICOMMANAGER_PROCESS_OBJECT_PATH,
									  MICOMMANAGER_EVENT_INTERFACE,
									  METHOD_MICOM_MANAGER_ROBUST,
									  DBUS_TYPE_INVALID);
	if (message != NULL)
	{
		if (!SendDBusMessage(message, NULL))
		{
			fprintf(stderr, "%s: SendDBusMessage failed\n", __FUNCTION__);
		}

		dbus_message_unref(message);
	}
	else
	{
		fprintf(stderr, "%s: CreateDBusMsgMethodCall failed\n", __FUNCTION__);
	}
}

void SendDBusTrvcReset()
{
	DBusMessage *message;

	TCLog(TCLogLevelInfo, "%s\n", __FUNCTION__);
	message = CreateDBusMsgMethodCall(MICOMMANAGER_PROCESS_DBUS_NAME, MICOMMANAGER_PROCESS_OBJECT_PATH,
									  MICOMMANAGER_EVENT_INTERFACE,
									  METHOD_MICOM_MANAGER_RESET,
									  DBUS_TYPE_INVALID);
	if (message != NULL)
	{
		if (!SendDBusMessage(message, NULL))
		{
			fprintf(stderr, "%s: SendDBusMessage failed\n", __FUNCTION__);
		}

		dbus_message_unref(message);
	}
	else
	{
		fprintf(stderr, "%s: CreateDBusMsgMethodCall failed\n", __FUNCTION__);
	}
}

static DBusMsgErrorCode OnReceivedDBusSignal(DBusMessage *message, const char *interface)
{
	DBusMsgErrorCode error = ErrorCodeNoError;


	fprintf(stderr, "%s\n", __FUNCTION__);
	if (message != NULL &&
		interface != NULL)
	{
		unsigned int index;
		unsigned int stop = 0;

		if (strcmp(interface, MICOMMANAGER_EVENT_INTERFACE) == 0)
		{
			for (index = SignalMicomManagerPower; index < TotalSignalMicomManagerEvents && !stop; index++)
			{
				if (dbus_message_is_signal(message,
										   MICOMMANAGER_EVENT_INTERFACE,
										   g_signalMicomManagerEventNames[index]))
				{
					MicomManagerSignalDBusProcess(index, message);
					stop = 1;
				}
			}
		}

		if (!stop)
		{
			error = ErrorCodeUnknown;
		}
	}
	
	return error;
}

static void MicomManagerSignalDBusProcess(unsigned int id, DBusMessage *message)
{
	if (id < TotalSignalMicomManagerEvents)
	{
		if (message != NULL)
		{
			switch (id)
			{
				case SignalMicomManagerTrvcOn:
					break;
				default:
					TCLog(TCLogLevelDebug, "%s: unknown signal id(%d)\n", __FUNCTION__, id);
					break;
			}
		}
	}
}
