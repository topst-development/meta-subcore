#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include <stdint.h>
#include "TCLog.h"
#include "TCInput.h"
#include "trvcDBusManager.h"
#include "trvcIFManager.h"


extern int g_debug;

TrvcIFManager::TrvcIFManager(QObject *parent) :
		QObject(parent),
		_rGear(false)
{
}

void TrvcIFManager::Initilaize(void)
{
	InitilaizeTrvcDBusManager();

}

void TrvcIFManager::Release(void)
{
	ReleaseTrvcDBusManager();
}

void TrvcIFManager::SendTrvcStatus(bool status)
{
	if(_rGear != status)
	{
		_rGear = status;
		if(_rGear == true)
		{
			SendDBusTrvcOn();
		}
		else
		{
			SendDBusTrvcOff();
		}
	}
}

void TrvcIFManager::SendTrvcRobust()
{
	SendDBusTrvcRobust();
}

void TrvcIFManager::SendTrvcReset()
{
	SendDBusTrvcReset();
}

static TrvcIFManager _manager;
TrvcIFManager *GetTrvcIFManager()
{
    return &_manager;
}

